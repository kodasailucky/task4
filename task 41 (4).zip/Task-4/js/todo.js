// My Personal Todo List App
// This handles all the todo functionality with localStorage

class TodoApp {
    constructor() {
        // Load saved todos from localStorage or start with empty array
        this.todos = JSON.parse(localStorage.getItem('myTodos')) || [];
        
        // Current filter setting
        this.currentFilter = 'all';
        
        // Start the app
        this.initializeApp();
    }

    // Initialize everything when the app starts
    initializeApp() {
        this.setupEventListeners();
        this.renderTodoList();
        this.updateStats();
    }

    // Set up all the click and input event listeners
    setupEventListeners() {
        // Add new todo button
        const addButton = document.getElementById('add-todo');
        const todoInput = document.getElementById('todo-input');

        if (addButton && todoInput) {
            addButton.addEventListener('click', () => this.addNewTodo());
            
            // Allow adding todo with Enter key
            todoInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.addNewTodo();
                }
            });
        }

        // Filter buttons
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.changeFilter(btn.dataset.filter);
            });
        });

        // Clear buttons
        const clearCompletedBtn = document.getElementById('clear-completed');
        const clearAllBtn = document.getElementById('clear-all');

        if (clearCompletedBtn) {
            clearCompletedBtn.addEventListener('click', () => this.clearCompletedTodos());
        }
        if (clearAllBtn) {
            clearAllBtn.addEventListener('click', () => this.clearAllTodos());
        }
    }

    // Add a new todo item
    addNewTodo() {
        const input = document.getElementById('todo-input');
        const todoText = input.value.trim();

        // Check if input is empty
        if (todoText === '') {
            this.showNotification('Please enter a task!', 'error');
            return;
        }

        // Create new todo object
        const newTodo = {
            id: Date.now(), // Use timestamp as unique ID
            text: todoText,
            completed: false,
            createdAt: new Date().toISOString()
        };

        // Add to beginning of array (newest first)
        this.todos.unshift(newTodo);
        
        // Save and update display
        this.saveTodos();
        this.renderTodoList();
        this.updateStats();

        // Clear input field
        input.value = '';
        
        // Show success message
        this.showNotification('Task added successfully!', 'success');
    }

    // Toggle todo completion status
    toggleTodo(id) {
        const todo = this.todos.find(t => t.id === id);
        if (todo) {
            todo.completed = !todo.completed;
            this.saveTodos();
            this.renderTodoList();
            this.updateStats();
        }
    }

    // Delete a specific todo
    deleteTodo(id) {
        this.todos = this.todos.filter(t => t.id !== id);
        this.saveTodos();
        this.renderTodoList();
        this.updateStats();
        this.showNotification('Task deleted!', 'success');
    }

    // Edit todo text
    editTodo(id, newText) {
        const todo = this.todos.find(t => t.id === id);
        if (todo && newText.trim() !== '') {
            todo.text = newText.trim();
            this.saveTodos();
            this.renderTodoList();
            this.showNotification('Task updated!', 'success');
        }
    }

    // Change the current filter
    changeFilter(filter) {
        this.currentFilter = filter;
        
        // Update active filter button styling
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-filter="${filter}"]`).classList.add('active');
        
        // Re-render the list
        this.renderTodoList();
    }

    // Get todos based on current filter
    getFilteredTodos() {
        switch (this.currentFilter) {
            case 'completed':
                return this.todos.filter(todo => todo.completed);
            case 'pending':
                return this.todos.filter(todo => !todo.completed);
            default:
                return this.todos; // Show all
        }
    }

    // Clear all completed todos
    clearCompletedTodos() {
        const completedCount = this.todos.filter(t => t.completed).length;
        this.todos = this.todos.filter(t => !t.completed);
        this.saveTodos();
        this.renderTodoList();
        this.updateStats();
        this.showNotification(`${completedCount} completed tasks cleared!`, 'success');
    }

    // Clear all todos
    clearAllTodos() {
        if (this.todos.length === 0) {
            this.showNotification('No tasks to clear!', 'error');
            return;
        }

        // Ask for confirmation
        if (confirm('Are you sure you want to delete all tasks?')) {
            const count = this.todos.length;
            this.todos = [];
            this.saveTodos();
            this.renderTodoList();
            this.updateStats();
            this.showNotification(`${count} tasks cleared!`, 'success');
        }
    }

    // Display todos in the list
    renderTodoList() {
        const todoList = document.getElementById('todo-list');
        if (!todoList) return;

        const filteredTodos = this.getFilteredTodos();

        // Show empty state if no todos
        if (filteredTodos.length === 0) {
            todoList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <h4>No tasks found</h4>
                    <p>${this.currentFilter === 'all' ? 'Add a new task to get started!' : `No ${this.currentFilter} tasks.`}</p>
                </div>
            `;
            return;
        }

        // Create HTML for each todo
        todoList.innerHTML = filteredTodos.map(todo => `
            <div class="todo-item ${todo.completed ? 'completed' : ''}" data-id="${todo.id}">
                <input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''}>
                <span class="todo-text" contenteditable="${!todo.completed}">${this.escapeHtml(todo.text)}</span>
                <button class="delete-btn" title="Delete task">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');

        // Add event listeners to each todo item
        this.addTodoItemListeners();
    }

    // Add event listeners to individual todo items
    addTodoItemListeners() {
        const todoList = document.getElementById('todo-list');
        if (!todoList) return;

        todoList.querySelectorAll('.todo-item').forEach(item => {
            const id = parseInt(item.dataset.id);
            const checkbox = item.querySelector('.todo-checkbox');
            const text = item.querySelector('.todo-text');
            const deleteBtn = item.querySelector('.delete-btn');

            // Toggle completion
            checkbox.addEventListener('change', () => this.toggleTodo(id));

            // Edit text (blur event)
            text.addEventListener('blur', () => {
                this.editTodo(id, text.textContent);
            });

            // Handle Enter key in editable text
            text.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    text.blur(); // Save changes
                }
            });

            // Delete todo
            deleteBtn.addEventListener('click', () => this.deleteTodo(id));
        });
    }

    // Update the statistics display
    updateStats() {
        const total = this.todos.length;
        const completed = this.todos.filter(t => t.completed).length;
        const pending = total - completed;

        // Update the stats elements
        const totalElement = document.getElementById('total-tasks');
        const completedElement = document.getElementById('completed-tasks');
        const pendingElement = document.getElementById('pending-tasks');

        if (totalElement) totalElement.textContent = `Total: ${total}`;
        if (completedElement) completedElement.textContent = `Completed: ${completed}`;
        if (pendingElement) pendingElement.textContent = `Pending: ${pending}`;
    }

    // Save todos to localStorage
    saveTodos() {
        localStorage.setItem('myTodos', JSON.stringify(this.todos));
    }

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Show notification message
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        const iconClass = type === 'success' ? 'check-circle' : 
                         type === 'error' ? 'exclamation-circle' : 'info-circle';
        
        notification.innerHTML = `
            <i class="fas fa-${iconClass}"></i>
            <span>${message}</span>
        `;

        // Add notification styles if not already present
        this.addNotificationStyles();

        // Add to page
        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // Add CSS styles for notifications
    addNotificationStyles() {
        if (document.getElementById('notification-styles')) return;

        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                animation: slideInRight 0.3s ease;
                max-width: 300px;
            }
            
            .notification-success {
                background: #28a745;
            }
            
            .notification-error {
                background: #dc3545;
            }
            
            .notification-info {
                background: #17a2b8;
            }
            
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            .notification.fade-out {
                animation: slideOutRight 0.3s ease forwards;
            }
            
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Start the todo app when the page loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('todo-list')) {
        new TodoApp();
    }
}); 